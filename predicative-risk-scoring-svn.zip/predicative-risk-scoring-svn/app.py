```python
from flask import Flask, render_template, request, jsonify
import sqlite3
from contextlib import contextmanager
from pathlib import Path

from risk_model import calculate_risk


# ==================================================
# 1. APPLICATION CONFIGURATION
# ==================================================

BASE_DIR = Path(__file__).resolve().parent
DATABASE = BASE_DIR / "risk_scoring.db"

app = Flask(__name__)
app.config["JSON_SORT_KEYS"] = False


# ==================================================
# 2. DATABASE CONNECTION MANAGEMENT
# ==================================================

@contextmanager
def get_db():
    """
    Open a SQLite connection.

    Commit successful operations.
    Roll back failed operations.
    Always close the connection.
    """

    connection = sqlite3.connect(str(DATABASE))
    connection.row_factory = sqlite3.Row

    try:
        yield connection
        connection.commit()

    except Exception:
        connection.rollback()
        raise

    finally:
        connection.close()


# ==================================================
# 3. DATABASE INITIALIZATION
# ==================================================

def init_db():
    """Create the required tables and audit records."""

    with get_db() as db:

        db.execute("""
            CREATE TABLE IF NOT EXISTS configuration_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                version TEXT NOT NULL,
                owner TEXT NOT NULL,
                status TEXT NOT NULL,
                change_description TEXT NOT NULL,
                approval TEXT NOT NULL
            )
        """)

        db.execute("""
            CREATE TABLE IF NOT EXISTS releases (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                changes INTEGER NOT NULL,
                modified_cis INTEGER NOT NULL,
                defects INTEGER NOT NULL,
                impact INTEGER NOT NULL,
                score INTEGER NOT NULL,
                level TEXT NOT NULL,
                recommendation TEXT NOT NULL
            )
        """)

        db.execute("""
            CREATE TABLE IF NOT EXISTS audit_checks (
                id INTEGER PRIMARY KEY,
                description TEXT NOT NULL,
                completed INTEGER NOT NULL DEFAULT 0
            )
        """)

        checks = [
            "SRS is version controlled",
            "SCM Plan is approved",
            "Configuration Items are identified",
            "Each CI has a unique ID and version",
            "Source code is maintained in Git",
            "CI changes and commits are recorded",
            "Change requests are recorded",
            "Risk algorithm is verified",
            "Test cases and reports are available",
            "Release package contains approved versions"
        ]

        for index, description in enumerate(checks, start=1):

            db.execute("""
                INSERT OR IGNORE INTO audit_checks
                (id, description)
                VALUES (?, ?)
            """, (index, description))


# ==================================================
# 4. HOME PAGE
# ==================================================

@app.route("/")
def home():
    return render_template("index.html")


# ==================================================
# 5. DASHBOARD API
# ==================================================

@app.route("/api/dashboard", methods=["GET"])
def dashboard():

    with get_db() as db:

        total_items = db.execute("""
            SELECT COUNT(*)
            FROM configuration_items
        """).fetchone()[0]

        latest = db.execute("""
            SELECT *
            FROM releases
            ORDER BY id DESC
            LIMIT 1
        """).fetchone()

        completed = db.execute("""
            SELECT COUNT(*)
            FROM audit_checks
            WHERE completed = 1
        """).fetchone()[0]

        total_checks = db.execute("""
            SELECT COUNT(*)
            FROM audit_checks
        """).fetchone()[0]

    return jsonify({
        "total_items": total_items,
        "latest_release": dict(latest) if latest else None,
        "audit_completed": completed,
        "audit_total": total_checks
    })


# ==================================================
# 6. RISK CALCULATION API
# ==================================================

@app.route("/api/risk", methods=["POST"])
def risk():

    data = request.get_json(silent=True)

    if not isinstance(data, dict):
        return jsonify({
            "error": "Send a valid JSON object."
        }), 400

    name = data.get("name")

    if not isinstance(name, str) or not name.strip():
        return jsonify({
            "error": "Release name is required."
        }), 400

    try:
        inputs = {}

        for field in (
            "changes",
            "modified_cis",
            "defects",
            "impact"
        ):

            value = data.get(field)

            # Reject strings, floats and Boolean values.
            if type(value) is not int:
                raise ValueError(
                    f"{field} must be a whole number."
                )

            inputs[field] = value

        result = calculate_risk(
            inputs["changes"],
            inputs["modified_cis"],
            inputs["defects"],
            inputs["impact"]
        )

    except ValueError as error:
        return jsonify({
            "error": str(error)
        }), 400

    return jsonify({
        "name": name.strip(),
        **inputs,
        **result
    })


# ==================================================
# 7. RELEASE MANAGEMENT API
# ==================================================

@app.route("/api/releases", methods=["GET", "POST"])
def releases():

    # Retrieve all releases.
    if request.method == "GET":

        with get_db() as db:

            rows = db.execute("""
                SELECT *
                FROM releases
                ORDER BY id DESC
            """).fetchall()

        return jsonify([
            dict(row) for row in rows
        ])

    # Create a new release.
    data = request.get_json(silent=True)

    if not isinstance(data, dict):
        return jsonify({
            "error": "Send a valid JSON object."
        }), 400

    name = data.get("name")

    if not isinstance(name, str) or not name.strip():
        return jsonify({
            "error": "Release name is required."
        }), 400

    try:
        values = []

        for field in (
            "changes",
            "modified_cis",
            "defects",
            "impact"
        ):

            value = data.get(field)

            if type(value) is not int:
                raise ValueError(
                    f"{field} must be a whole number."
                )

            values.append(value)

        result = calculate_risk(*values)

    except ValueError as error:
        return jsonify({
            "error": str(error)
        }), 400

    with get_db() as db:

        cursor = db.execute("""
            INSERT INTO releases (
                name,
                changes,
                modified_cis,
                defects,
                impact,
                score,
                level,
                recommendation
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            name.strip(),
            *values,
            result["score"],
            result["level"],
            result["recommendation"]
        ))

        release_id = cursor.lastrowid

        row = db.execute("""
            SELECT *
            FROM releases
            WHERE id = ?
        """, (release_id,)).fetchone()

        response_data = dict(row)

    return jsonify(response_data), 201


# ==================================================
# 8. CONFIGURATION ITEM MANAGEMENT API
# ==================================================

@app.route("/api/configuration-items", methods=["GET", "POST"])
def configuration_items():

    # Retrieve configuration items.
    if request.method == "GET":

        with get_db() as db:

            rows = db.execute("""
                SELECT *
                FROM configuration_items
                ORDER BY id DESC
            """).fetchall()

        return jsonify([
            dict(row) for row in rows
        ])

    # Add a configuration item.
    data = request.get_json(silent=True)

    if not isinstance(data, dict):
        return jsonify({
            "error": "Send a valid JSON object."
        }), 400

    fields = (
        "name",
        "version",
        "owner",
        "status",
        "change_description",
        "approval"
    )

    values = []

    for field in fields:

        value = data.get(field)

        if not isinstance(value, str) or not value.strip():
            return jsonify({
                "error": f"{field} is required."
            }), 400

        values.append(value.strip())

    valid_statuses = (
        "Development",
        "Under Review",
        "Testing",
        "Approved",
        "Completed",
        "Pending"
    )

    if values[3] not in valid_statuses:
        return jsonify({
            "error": "Invalid configuration item status."
        }), 400

    valid_approvals = (
        "Pending",
        "Approved",
        "Rejected"
    )

    if values[5] not in valid_approvals:
        return jsonify({
            "error": "Invalid approval status."
        }), 400

    with get_db() as db:

        cursor = db.execute("""
            INSERT INTO configuration_items (
                name,
                version,
                owner,
                status,
                change_description,
                approval
            )
            VALUES (?, ?, ?, ?, ?, ?)
        """, values)

        item_id = cursor.lastrowid

        row = db.execute("""
            SELECT *
            FROM configuration_items
            WHERE id = ?
        """, (item_id,)).fetchone()

        response_data = dict(row)

    return jsonify(response_data), 201


# ==================================================
# 9. AUDIT CHECK API
# ==================================================

@app.route("/api/audit", methods=["GET"])
def get_audit():

    with get_db() as db:

        rows = db.execute("""
            SELECT *
            FROM audit_checks
            ORDER BY id
        """).fetchall()

    return jsonify([
        dict(row) for row in rows
    ])


# ==================================================
# 10. UPDATE AUDIT CHECK API
# ==================================================

@app.route("/api/audit/<int:check_id>", methods=["PUT"])
def update_audit(check_id):

    data = request.get_json(silent=True)

    if (
        not isinstance(data, dict)
        or type(data.get("completed")) is not bool
    ):
        return jsonify({
            "error": "completed must be true or false."
        }), 400

    with get_db() as db:

        cursor = db.execute("""
            UPDATE audit_checks
            SET completed = ?
            WHERE id = ?
        """, (
            int(data["completed"]),
            check_id
        ))

        if cursor.rowcount == 0:
            return jsonify({
                "error": "Audit check not found."
            }), 404

        row = db.execute("""
            SELECT *
            FROM audit_checks
            WHERE id = ?
        """, (check_id,)).fetchone()

        response_data = dict(row)

    return jsonify(response_data)


# ==================================================
# 11. INITIALIZE DATABASE
# ==================================================

init_db()


# ==================================================
# 12. START APPLICATION
# ==================================================

if __name__ == "__main__":
    app.run(debug=True)
```
