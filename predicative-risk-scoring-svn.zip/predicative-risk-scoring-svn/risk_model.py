
def calculate_risk(changes, modified_cis, defects, impact):
    """Return a demonstration release risk score from 0 to 100."""

    values = (changes, modified_cis, defects, impact)

    if any(isinstance(v, bool) or not isinstance(v, int) for v in values):
        raise ValueError("All risk inputs must be whole numbers.")

    if not 0 <= changes <= 1000:
        raise ValueError("Changes must be between 0 and 1000.")

    if not 0 <= modified_cis <= 100:
        raise ValueError("Modified CIs must be between 0 and 100.")

    if not 0 <= defects <= 100:
        raise ValueError("Defects must be between 0 and 100.")

    if impact not in (1, 2, 3):
        raise ValueError("Impact must be 1, 2, or 3.")

    change_points = min(changes / 20, 1) * 25
    ci_points = min(modified_cis / 10, 1) * 25
    defect_points = min(defects / 10, 1) * 25
    impact_points = (impact / 3) * 25

    score = round(
        change_points + ci_points + defect_points + impact_points
    )

    if score <= 33:
        level = "LOW"
        recommendation = "Proceed to normal approval and release checks."
    elif score <= 66:
        level = "MEDIUM"
        recommendation = (
            "Review changes, verify tests, and obtain approval."
        )
    else:
        level = "HIGH"
        recommendation = (
            "Investigate risks and resolve critical issues before approval."
        )

    return {
        "score": score,
        "level": level,
        "recommendation": recommendation
    }
