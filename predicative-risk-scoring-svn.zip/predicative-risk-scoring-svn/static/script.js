
const $ = id => document.getElementById(id);

let latestRelease = null;

async function api(url, options = {}) {
    const response = await fetch(url, {
        ...options,
        headers: {
            "Content-Type": "application/json",
            ...(options.headers || {})
        }
    });

    const data = await response.json();

    if (!response.ok) {
        throw new Error(data.error || "Request failed.");
    }

    return data;
}

function showMessage(message) {
    $("message").textContent = message;
}

function addCell(row, value) {
    const cell = document.createElement("td");
    cell.textContent = value ?? "";
    row.appendChild(cell);
}

async function loadDashboard() {
    const data = await api("/api/dashboard");

    $("totalItems").textContent = data.total_items;
    $("auditCount").textContent =
        `${data.audit_completed} / ${data.audit_total}`;

    if (data.latest_release) {
        $("dashboardScore").textContent =
            `${data.latest_release.score} / 100`;
        $("dashboardLevel").textContent = data.latest_release.level;
    } else {
        $("dashboardScore").textContent = "--";
        $("dashboardLevel").textContent = "Not calculated";
    }
}

async function loadItems() {
    const items = await api("/api/configuration-items");
    const table = $("ciTable");
    table.replaceChildren();

    items.forEach(item => {
        const row = document.createElement("tr");

        [
            "CI-" + String(item.id).padStart(3, "0"),
            item.name,
            item.version,
            item.owner,
            item.status,
            item.change_description,
            item.approval
        ].forEach(value => addCell(row, value));

        table.appendChild(row);
    });

    $("totalItems").textContent = items.length;
}

async function loadReleases() {
    const releases = await api("/api/releases");
    const table = $("releaseTable");
    table.replaceChildren();

    releases.forEach(release => {
        const row = document.createElement("tr");

        [
            release.name,
            release.changes,
            `${release.score} / 100`,
            release.level,
            release.recommendation
        ].forEach(value => addCell(row, value));

        table.appendChild(row);
    });

    if (releases.length) {
        $("dashboardScore").textContent =
            `${releases[0].score} / 100`;
        $("dashboardLevel").textContent = releases[0].level;
    }
}

$("riskForm").addEventListener("submit", async event => {
    event.preventDefault();
    latestRelease = null;
    $("saveRelease").disabled = true;

    try {
        const result = await api("/api/risk", {
            method: "POST",
            body: JSON.stringify({
                name: $("releaseName").value.trim(),
                changes: Number($("changes").value),
                modified_cis: Number($("modifiedCIs").value),
                defects: Number($("defects").value),
                impact: Number($("impact").value)
            })
        });

        latestRelease = result;

        $("riskResult").className = "result risk-" +
            result.level.toLowerCase();

        $("riskResult").replaceChildren();

        const heading = document.createElement("h3");
        heading.textContent = "Risk Analysis Result";

        const score = document.createElement("p");
        score.textContent = `Risk Score: ${result.score} / 100`;

        const level = document.createElement("p");
        level.textContent = `Risk Level: ${result.level}`;

        const recommendation = document.createElement("p");
        recommendation.textContent =
            `Recommendation: ${result.recommendation}`;

        $("riskResult").append(heading, score, level, recommendation);

        $("riskBar").style.width = `${result.score}%`;
        $("riskBar").style.background =
            result.level === "LOW" ? "#24864b" :
            result.level === "MEDIUM" ? "#d99a13" : "#c73737";

        $("dashboardScore").textContent = `${result.score} / 100`;
        $("dashboardLevel").textContent = result.level;
        $("saveRelease").disabled = false;
        showMessage("Risk calculation completed.");
    } catch (error) {
        $("riskResult").className = "result";
        $("riskResult").textContent = error.message;
        $("riskBar").style.width = "0";
        showMessage("Risk calculation failed.");
    }
});

$("saveRelease").addEventListener("click", async () => {
    if (!latestRelease) return;

    try {
        await api("/api/releases", {
            method: "POST",
            body: JSON.stringify({
                name: latestRelease.name,
                changes: latestRelease.changes,
                modified_cis: latestRelease.modified_cis,
                defects: latestRelease.defects,
                impact: latestRelease.impact
            })
        });

        latestRelease = null;
        $("saveRelease").disabled = true;

        await loadReleases();
        await loadDashboard();
        showMessage("Release record saved to the database.");
    } catch (error) {
        showMessage(error.message);
    }
});

$("ciForm").addEventListener("submit", async event => {
    event.preventDefault();

    try {
        await api("/api/configuration-items", {
            method: "POST",
            body: JSON.stringify({
                name: $("ciName").value.trim(),
                version: $("ciVersion").value.trim(),
                owner: $("ciOwner").value.trim(),
                status: $("ciStatus").value,
                change_description: $("ciChange").value.trim(),
                approval: $("ciApproval").value
            })
        });

        event.target.reset();
        await loadItems();
        await loadDashboard();
        showMessage("Configuration item saved successfully.");
    } catch (error) {
        showMessage(error.message);
    }
});

async function loadAudit() {
    const checks = await api("/api/audit");
    const list = $("auditList");
    list.replaceChildren();

    checks.forEach(check => {
        const label = document.createElement("label");
        label.className = "audit-item";

        const checkbox = document.createElement("input");
        checkbox.type = "checkbox";
        checkbox.checked = Boolean(check.completed);
        checkbox.setAttribute("aria-label", check.description);

        const text = document.createElement("span");
        text.textContent = check.description;

        checkbox.addEventListener("change", async () => {
            checkbox.disabled = true;

            try {
                await api(`/api/audit/${check.id}`, {
                    method: "PUT",
                    body: JSON.stringify({
                        completed: checkbox.checked
                    })
                });

                await loadDashboard();
                showMessage("Audit progress saved.");
            } catch (error) {
                checkbox.checked = !checkbox.checked;
                showMessage(error.message);
            } finally {
                checkbox.disabled = false;
            }
        });

        label.append(checkbox, text);
        list.appendChild(label);
    });
}

async function startApplication() {
    try {
        await Promise.all([
            loadDashboard(),
            loadItems(),
            loadReleases(),
            loadAudit()
        ]);
        showMessage("Application connected to the backend.");
    } catch (error) {
        showMessage("Could not connect to backend: " + error.message);
    }
}

startApplication();
