
```python
import os
import tempfile
import unittest

import app as application
from risk_model import calculate_risk


# ==================================================
# 1. RISK MODEL TESTS
# ==================================================

class RiskModelTests(unittest.TestCase):

    def test_medium_risk_example(self):
        result = calculate_risk(10, 3, 2, 2)

        self.assertEqual(result["score"], 42)
        self.assertEqual(result["level"], "MEDIUM")

    def test_high_risk_example(self):
        result = calculate_risk(100, 10, 10, 3)

        self.assertEqual(result["score"], 100)
        self.assertEqual(result["level"], "HIGH")

    def test_zero_inputs(self):
        result = calculate_risk(0, 0, 0, 1)

        self.assertEqual(result["score"], 8)
        self.assertEqual(result["level"], "LOW")

    def test_invalid_input(self):
        with self.assertRaises(ValueError):
            calculate_risk(-1, 3, 2, 2)

    def test_invalid_impact(self):
        with self.assertRaises(ValueError):
            calculate_risk(10, 3, 2, 4)


# ==================================================
# 2. BACKEND API TESTS
# ==================================================

class BackendTests(unittest.TestCase):

    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()

        self.old_database = application.DATABASE
        self.old_testing = application.app.config.get(
            "TESTING", False
        )

        application.DATABASE = os.path.join(
            self.temp_dir.name,
            "test.db"
        )

        application.app.config["TESTING"] = True

        self.client = application.app.test_client()

        try:
            application.init_db()

        except Exception:
            application.DATABASE = self.old_database
            application.app.config["TESTING"] = self.old_testing
            self.temp_dir.cleanup()
            raise

    def tearDown(self):
        # Release the test client reference.
        self.client = None

        # Restore the original application configuration.
        application.DATABASE = self.old_database
        application.app.config["TESTING"] = self.old_testing

        # Remove the temporary database.
        # This succeeds when all database connections are closed.
        self.temp_dir.cleanup()

    def test_home_page(self):
        response = self.client.get("/")

        self.assertEqual(response.status_code, 200)

        self.assertIn(
            b"Predictive Release Risk Scoring",
            response.data
        )

    def test_risk_api(self):
        response = self.client.post(
            "/api/risk",
            json={
                "name": "Release Test",
                "changes": 10,
                "modified_cis": 3,
                "defects": 2,
                "impact": 2
            }
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json["score"], 42)
        self.assertEqual(response.json["level"], "MEDIUM")

    def test_reject_invalid_risk_input(self):
        response = self.client.post(
            "/api/risk",
            json={
                "name": "Invalid Release",
                "changes": -1,
                "modified_cis": 3,
                "defects": 2,
                "impact": 2
            }
        )

        self.assertEqual(response.status_code, 400)

    def test_save_configuration_item(self):
        response = self.client.post(
            "/api/configuration-items",
            json={
                "name": "Risk Algorithm",
                "version": "v2.0",
                "owner": "Development Team",
                "status": "Testing",
                "change_description": "Added defect history",
                "approval": "Pending"
            }
        )

        self.assertEqual(response.status_code, 201)

        items = self.client.get(
            "/api/configuration-items"
        )

        self.assertEqual(len(items.json), 1)

        self.assertEqual(
            items.json[0]["name"],
            "Risk Algorithm"
        )

    def test_save_release(self):
        response = self.client.post(
            "/api/releases",
            json={
                "name": "Release v2.0",
                "changes": 10,
                "modified_cis": 3,
                "defects": 2,
                "impact": 2
            }
        )

        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.json["score"], 42)

    def test_update_audit_check(self):
        response = self.client.put(
            "/api/audit/1",
            json={"completed": True}
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json["completed"], 1)

    def test_reject_invalid_audit_check(self):
        response = self.client.put(
            "/api/audit/1",
            json={"completed": "yes"}
        )

        self.assertEqual(response.status_code, 400)


# ==================================================
# 3. RUN TESTS
# ==================================================

if __name__ == "__main__":
    unittest.main(verbosity=2)
```
